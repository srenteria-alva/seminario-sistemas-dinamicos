II Seminario Internacional de Sistemas Dinámicos — UNT

Archivo principal: index.html

PUBLICAR EN GITHUB PAGES
1. Entra en https://github.com e inicia sesión.
2. Pulsa el botón + (arriba a la derecha) > New repository.
3. Nombre del repositorio: seminario-sistemas-dinamicos
4. Selecciona Public y pulsa Create repository.
5. Dentro del repositorio, pulsa Add file > Upload files.
6. Sube index.html y pulsa Commit changes.
7. En el repositorio, entra en Settings > Pages.
8. En Build and deployment, selecciona Deploy from a branch.
9. Branch: main; folder: /(root). Pulsa Save.
10. Espera unos minutos. GitHub mostrará la URL publicada en esa misma sección.

IMPORTANTE
- Sustituye REEMPLAZAR_CORREO@ejemplo.com por el correo oficial.
- Añade el enlace real del formulario de inscripción cuando lo tengas.
- Completa ponentes, títulos, horarios y enlaces de las sesiones cuando estén confirmados.
- La URL final depende del nombre de usuario de GitHub.
